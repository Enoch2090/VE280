#include "binaryTree.h"
#include "huffmanTree.h"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

void decompress()
{
}

int main(int argc, char *argv[])
{
    cout << " " << endl;
}